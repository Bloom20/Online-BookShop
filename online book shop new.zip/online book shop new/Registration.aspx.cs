﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
       
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        //string insert = "insert into registration  (User name,Password,Confirm password) values (@User name,@Password,@Confirm password)";
        SqlCommand cmd = new SqlCommand("insert into Registration2 (User_name,Password,Confirm_password) values (@User_name,@Password,@Confirm_password)", con);
        cmd.Parameters.AddWithValue("@User_name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Password", TextBox2.Text);
        cmd.Parameters.AddWithValue("@Confirm_password", TextBox3.Text);
        cmd.ExecuteNonQuery();
        con.Close();
        
 
    }
         
       
        
}