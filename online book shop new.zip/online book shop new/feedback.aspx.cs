﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["connectionstring"].ConnectionString);
        con.Open();
        //string insert = "insert into feedback (Name,Adress,Feedback) values (@Name,@Adress,@Feedback)";
        SqlCommand cmd = new SqlCommand("insert into feedback (Name,Adress,Feedback) values (@Name,@Adress,@Feedback)", con);
        cmd.Parameters.AddWithValue("@Name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Adress", TextBox2.Text);
        cmd.Parameters.AddWithValue("@Feedback", TextBox3.Text);
        cmd.ExecuteNonQuery();
        con.Close();

    }
}