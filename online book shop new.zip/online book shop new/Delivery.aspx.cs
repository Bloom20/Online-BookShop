﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Default2 : System.Web.UI.Page
{
   
    protected void Button1_Click1(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        //String insert = " insert into delivery (Name,Address,Pin_code,Contact_no) values (@Name,@Address,@Pin_code,@Contact_no)";
        SqlCommand cmd = new SqlCommand("insert into delivery (Name,Address,Pin_code,Contact_no) values (@Name,@Address,@Pin_code,@Contact_no)", con);
        cmd.Parameters.AddWithValue("@Name", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Address", TextBox2.Text);
        cmd.Parameters.AddWithValue("@Pin_code", TextBox3.Text);
        cmd.Parameters.AddWithValue("@Contact_no", TextBox4.Text);
        cmd.ExecuteNonQuery();
        Label9.Text = "Order Successfully Placed";
        con.Close();


    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}